# SimpleFuelSwitch
Lets you toggle fuel type for tanks in the vehicle edior (e.g. choose between LFO and liquid-fuel-only).
